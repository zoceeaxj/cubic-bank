package com.rab3tech.customer.service;

public interface CustomerService {

}
