package com.rab3tech.customer.service.impl;

import org.springframework.stereotype.Service;

import com.rab3tech.customer.service.CustomerService;

@Service
public class CustomerServiceImpl implements  CustomerService{

}
